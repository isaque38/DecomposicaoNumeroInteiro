/*
 *@author: Isaque de Lima Vieira
 *RA: 1110482123042
 */

package com.example.decomposicaonumero;

import androidx.appcompat.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;

public class MainActivity extends AppCompatActivity {

    private EditText etNumero;
    private TextView tvResultado;
    private Button btnDecompor;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        etNumero = findViewById(R.id.etNumero);
        tvResultado = findViewById(R.id.tvResultado);
        btnDecompor = findViewById(R.id.btnDecompor);

        btnDecompor.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                decomporNumero();
            }
        });
    }

    private void decomporNumero() {
        int numero = Integer.parseInt(etNumero.getText().toString());

        if (numero >= 100 && numero <= 999) {
            int centena = numero / 100;
            int dezena = (numero % 100) / 10;
            int unidade = numero % 10;

            tvResultado.setText("CENTENA = " + centena + "\nDEZENA = " + dezena + "\nUNIDADE = " + unidade);
        } else {
            tvResultado.setText("Por favor, insira um número entre 100 e 999.");
        }
    }
}